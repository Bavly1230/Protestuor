/**
 * @file BotAI Slash Command.
 * @author TechyGiraffe999
 * @license Apache License 2.0
 */

const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, EmbedBuilder } = require("discord.js");
const { owner } = require("../../../config.json");

const no_access = new EmbedBuilder()
	.setDescription("**Only my developers can directly update my personality prompt!**\n\nIf you want to suggest a change, please let us know!")
	.setColor("Red");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('botai')
        .setDescription('Ask BotAI a question!')
        .addStringOption(option =>
			option.setName("options")
				.setDescription("Category info options")
				.setRequired(true)
				.addChoices(
					{ name: "Personalise", value: "personalise" },
					{ name: "Ask", value: "ask" }
				)),
    async execute(interaction) {
        const { options } = interaction;
        const categorys = options.getString('options');

        switch (categorys) {
            case "ask":
                const botai = new ModalBuilder()
					.setTitle("Ask BotAI something")
					.setCustomId("bot_ai");

				const question = new TextInputBuilder()
					.setCustomId("question_botai")
					.setRequired(true)
					.setLabel("Question:")
					.setStyle(TextInputStyle.Paragraph);
				const botai_question_ActionRow = new ActionRowBuilder().addComponents(question);
				botai.addComponents(botai_question_ActionRow);
				await interaction.showModal(botai);
				break;
            case "personalise":
				if (!owner.includes(interaction.user.id)) {
					return await interaction.reply({ embeds: [no_access], ephemeral: true });
				}

                const personalise = new ModalBuilder()
					.setTitle("Customise how BotAI responds")
					.setCustomId("bot_ai_personality");

				const prompt = new TextInputBuilder()
					.setCustomId("personalise_botai")
					.setRequired(true)
					.setLabel("Personality Prompt:")
					.setStyle(TextInputStyle.Paragraph);
				const prompt2 = new TextInputBuilder()
					.setCustomId("personalise_botai2")
					.setRequired(false)
					.setLabel("Extra Space:")
					.setStyle(TextInputStyle.Paragraph);
				const prompt3 = new TextInputBuilder()
					.setCustomId("personalise_botai3")
					.setRequired(false)
					.setLabel("Extra Space:")
					.setStyle(TextInputStyle.Paragraph);


				const botai_personality_ActionRow = new ActionRowBuilder().addComponents(prompt);
				const botai_personality_ActionRow2 = new ActionRowBuilder().addComponents(prompt2);
				const botai_personality_ActionRow3 = new ActionRowBuilder().addComponents(prompt3);

				personalise.addComponents(botai_personality_ActionRow, botai_personality_ActionRow2, botai_personality_ActionRow3);
				await interaction.showModal(personalise);
				break;

        }
    }
};